Config = Config or {}

Config.WelcomeVehicles = {
    { Model = "weevil", Chance = 0.5 },
    { Model = "panto", Chance = 0.8 },
    { Model = "rhapsody", Chance = 0.8 },
    { Model = "brioso2", Chance = 0.5 },
    { Model = "kalahari", Chance = 0.2 },
    { Model = "rebel", Chance = 0.7 },
    { Model = "dynasty", Chance = 0.1 },
    { Model = "fagaloa", Chance = 0.1 },
    { Model = "minivan", Chance = 0.5 }
}

-- Scene: base-game GTA Online 10-car garage (v_garagel), flat floor, no DLC IPL required.
-- The camera stands at the south end of the garage looking north along its length.
Config.SceneInterior = vector3(228.6, -992.0, -99.0) -- Any point inside the interior, used to load it.
Config.HideCoords = vector3(228.3, -1003.4, -99.0)    -- Player is frozen + invisible here while selecting.
Config.CamCoords = vector4(228.3, -1002.0, -98.4, 0.0)
Config.CamFov = 33.0
Config.CamHeight = 1.55 -- Camera height above the floor (eye level). Cameras are snapped to the floor at runtime.
-- Peds are snapped to the floor at runtime, so the Z value only has to be roughly right.
Config.PedCoords = {
    vector3(226.05, -997.535, -99.0),
    vector3(226.95, -997.187, -99.0),
    vector3(227.85, -997.020, -99.0),
    vector3(228.75, -997.020, -99.0),
    vector3(229.65, -997.187, -99.0),
    vector3(230.55, -997.535, -99.0),
}

-- Teal spotlight drawn above the highlighted character.
Config.Spotlight = {
    Color = { 40, 200, 255 },
    Height = 3.0,      -- Meters above the ped.
    Distance = 9.0,
    Brightness = 18.0,
    Radius = 24.0,
}

-- "New Character" body selection. The camera slides left from Config.CamCoords to CamCoords below.
-- Default values are 3.5m to the left (west) of the selection camera, inside the same garage.
Config.BodySelection = {
    CamCoords = vector4(224.8, -1002.0, -98.4, 0.0),
    CamFov = 40.0,
    TransitionTime = 1800, -- ms
    Peds = {
        -- Type A (left on screen)
        Man = {
            Model = "mp_m_freemode_01",
            Coords = vector3(224.0, -998.4, -99.0),
            HeadBlend = { 0, 0, 0.5 },
            Hair = { 4, 0 },
            -- [ComponentId] = { Drawable, Texture }
            Components = { [3] = { 15, 0 }, [4] = { 61, 0 }, [6] = { 34, 0 }, [8] = { 15, 0 }, [11] = { 15, 0 } },
        },
        -- Type B (right on screen)
        Vrouw = {
            Model = "mp_f_freemode_01",
            Coords = vector3(225.6, -998.4, -99.0),
            HeadBlend = { 21, 21, 0.5 },
            Hair = { 4, 0 },
            Components = { [3] = { 15, 0 }, [4] = { 15, 0 }, [6] = { 35, 0 }, [8] = { 14, 0 }, [11] = { 15, 0 } },
        },
    },
    -- Close-up camera used while filling in the name / birthdate, relative to the chosen ped.
    InfoCamOffset = vector3(0.0, 2.4, 0.35),
    InfoCamLookOffset = vector3(0.75, 0.0, 0.15),
    InfoCamFov = 40.0,
}

-- Array of STEAM IDs of players that may ingore character limit.
Config.LimitOverride = {
    ['STEAM_ID'] = true,
}

-- Spawns
-- Add at bottom!
Config.SpawnLocations = {
    {
        Id = "lastlocation",
        Name = "Last Location",
        Icon = 'fas fa-map-pin',
        Coords = { X = 0.0, Y = 0.0, Z = 0.0 },
        Type = 'Location',
        Hidden = false,
    },
    {
        Id = "apartment",
        Name = "No3 Appartement",
        Icon = 'fas fa-building',
        Color = '#f2a365',
        Coords = { X = -271.15, Y = -957.91, Z = 31.22 },
        Type = 'Apartment',
        Hidden = false,
    },
    {
        Id = "bus",
        Name = "Bus Station",
        Icon = "map-marker-alt",
        Coords = {X = 454.77, Y = -659.29, Z = 27.62, H = 177.66},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "motels",
        Name = "Motel Parking",
        Icon = "map-marker-alt",
        Coords = {X = 275.49, Y = -354.11, Z = 44.98, H = 154.26},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "pier",
        Name = "Del Perro Pier",
        Icon = "map-marker-alt",
        Coords = {X = -1648.76, Y = -994.26, Z = 13.02, H = 230.24},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "harmonymotel",
        Name = "Harmony Motel",
        Icon = "map-marker-alt",
        Coords = {X = 1122.11, Y =  2667.24, Z = 38.04, H = 180.39},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "paleto",
        Name = "Paleto Bay",
        Icon = "map-marker-alt",
        Coords = {X = 145.62, Y = 6563.19, Z = 32.0, H = 42.83},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "airport",
        Name = "Los Santos International Airport",
        Icon = "map-marker-alt",
        Coords = {X = -1037.68, Y = -2737.68, Z = 20.17, H = 331.25},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "vinewood",
        Name = "Vinewood Blvd. Taxi Stop",
        Icon = "map-marker-alt",
        Coords = {X = 272.16, Y = 185.44, Z = 104.67, H = 320.57},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "hospital",
        Name = "Crusade Medical Center Bus Stop",
        Icon = "map-marker-alt",
        Coords = {X = 374.22, Y = -1537.64, Z = 29.29, H = 139.53},
        Type = "Location",
        Hidden = false
    },
    {
        Id = "bolingbroke_penitentiary",
        Name = 'Bolingbroke Penitentiary',
        Icon = 'fas fa-voicemail',
        Coords = { X = 1845.903, Y = 2585.873, Z = 45.672 },
        Type = 'Jail',
        Hidden = true,
    },
}

function DeepCopyTable(Obj)
    if type(Obj) ~= 'table' then return Obj end
    local res = {}
    
    for k, v in pairs(Obj) do
        res[DeepCopyTable(k)] = DeepCopyTable(v)
    end

    return res
end