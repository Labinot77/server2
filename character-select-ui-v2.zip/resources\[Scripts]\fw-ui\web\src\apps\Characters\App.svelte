<script>
    import "@fontsource/barlow-condensed/600-italic.css";
    import "@fontsource/barlow-condensed/700-italic.css";
    import "@fontsource/barlow-condensed/800-italic.css";

    import AppWrapper from "../../components/AppWrapper.svelte";
    import { OnEvent, SendEvent as _SendEvent } from "../../utils/Utils";
    const SendEvent = (Event, Parameters, Callback) => _SendEvent(Event, Parameters, Callback, "fw-characters");

    // Stages: "select" (character slots) -> "body" (Type A / Type B) -> "info" (name + birthdate)
    let Visible = false;
    let Stage = "select";
    let Busy = false;

    let Characters = [];
    let SlotCount = 6;
    let MaxCharsOverride = false;

    // Screen projections of the in-game peds, sent by Lua. Values are 0..1 screen fractions.
    let Slots = [];
    let BodySlots = {};

    let Index = 0;
    let Gender = "Man"; // "Man" = Type A, "Vrouw" = Type B (values the server expects)

    let DeleteConfirm = false;
    let Toast = false;
    let ToastTimeout = null;

    let Form = { Firstname: "", Lastname: "", Birthdate: "" };
    let FormError = false;
    let FirstnameInput;

    const BodyTypes = [
        { Gender: "Man", Label: "TYPE A" },
        { Gender: "Vrouw", Label: "TYPE B" },
    ];

    // Every selectable entry: one per ped slot, then characters without a slot, then an extra "new" entry for limit overrides.
    $: Entries = BuildEntries(Characters, SlotCount, MaxCharsOverride);
    $: Current = Entries[Index] || Entries[0];

    const BuildEntries = (Chars, Count, Override) => {
        const List = [];
        for (let i = 0; i < Count; i++) {
            List.push(Chars[i] ? { Type: "char", Char: Chars[i], Slot: i } : { Type: "new", Slot: i });
        }
        for (let i = Count; i < Chars.length; i++) {
            List.push({ Type: "char", Char: Chars[i], Slot: null });
        }
        if (Chars.length >= Count && Override) {
            List.push({ Type: "new", Slot: null });
        }
        return List;
    };

    const ShowToast = (Text) => {
        Toast = Text;
        clearTimeout(ToastTimeout);
        ToastTimeout = setTimeout(() => { Toast = false; }, 4000);
    };

    const ResetState = () => {
        Stage = "select";
        Busy = false;
        DeleteConfirm = false;
        FormError = false;
        Gender = "Man";
        Form = { Firstname: "", Lastname: "", Birthdate: "" };
    };

    OnEvent("Characters", "LoadCharacters", (Data) => {
        Characters = Data.Characters || [];
        SlotCount = Data.SlotCount || 6;
        MaxCharsOverride = Data.AllowOverride;
        Slots = [];
        ResetState();
        if (Index >= BuildEntries(Characters, SlotCount, MaxCharsOverride).length) Index = 0;
    });

    OnEvent("Characters", "SetSlots", (Data) => {
        Slots = Data.Slots || [];
        SendHighlight();
    });

    OnEvent("Characters", "SetBodySlots", (Data) => {
        BodySlots = Data.Slots || {};
    });

    OnEvent("Characters", "SetVisibility", (Data) => {
        Visible = Data.Visible;
        if (!Visible) ResetState();
    });

    // Select stage
    const SendHighlight = () => {
        if (Stage != "select") return;
        SendEvent("Characters/SetHighlight", { Slot: Current && Current.Slot != null ? Current.Slot + 1 : false });
    };

    const SetIndex = (NewIndex) => {
        if (Busy || DeleteConfirm || !Entries.length) return;
        Index = (NewIndex + Entries.length) % Entries.length;
        SendHighlight();
    };

    const Activate = () => {
        if (Busy || !Current) return;

        if (Current.Type == "char") {
            Busy = true;
            Visible = false;
            SendEvent("Characters/PlayCharacter", { Cid: Current.Char.Cid });
            return;
        }

        if (Characters.length >= SlotCount && !MaxCharsOverride) {
            return ShowToast("Character limit reached.");
        }

        Busy = true;
        SendEvent("Characters/StartCreate", {}, () => {
            Stage = "body";
            Gender = "Man";
            Busy = false;
        });
    };

    const OpenDelete = () => {
        if (Busy || !Current || Current.Type != "char") return;
        DeleteConfirm = true;
    };

    const ConfirmDelete = () => {
        if (Busy) return;
        Busy = true;
        DeleteConfirm = false;
        Visible = false;
        SendEvent("Characters/DeleteCharacter", { Cid: Current.Char.Cid });
    };

    // Body stage
    const SetGender = (NewGender) => {
        if (Busy || Stage != "body") return;
        Gender = NewGender;
        SendEvent("Characters/SetBodyHighlight", { Gender });
    };

    const ToggleGender = () => SetGender(Gender == "Man" ? "Vrouw" : "Man");

    const ConfirmBody = () => {
        if (Busy) return;
        Busy = true;
        SendEvent("Characters/SelectBody", { Gender }, () => {
            Stage = "info";
            Busy = false;
            setTimeout(() => FirstnameInput && FirstnameInput.focus(), 50);
        });
    };

    const BackToSelect = () => {
        if (Busy) return;
        Busy = true;
        SendEvent("Characters/CancelCreate", {}, () => {
            Stage = "select";
            Busy = false;
            SendHighlight();
        });
    };

    // Info stage
    const BackToBody = () => {
        if (Busy) return;
        Busy = true;
        FormError = false;
        if (document.activeElement) document.activeElement.blur();
        SendEvent("Characters/BackToBody", { Gender }, () => {
            Stage = "body";
            Busy = false;
        });
    };

    const NameRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ' -]+$/;

    const SubmitInfo = () => {
        if (Busy) return;

        const Firstname = Form.Firstname.trim();
        const Lastname = Form.Lastname.trim();
        const Birthdate = Form.Birthdate.trim();

        if (!Firstname || !Lastname || !Birthdate) return FormError = "Fill in all fields.";
        if (Firstname.length > 20 || Lastname.length > 20) return FormError = "Names can be at most 20 characters.";
        if (!NameRegex.test(Firstname) || !NameRegex.test(Lastname)) return FormError = "Names may only contain letters.";

        const BirthYear = new Date(Birthdate).getFullYear();
        const MaxBirthyear = new Date().getFullYear() - 17;
        if (isNaN(BirthYear) || BirthYear < (MaxBirthyear - 101) || BirthYear >= MaxBirthyear) {
            return FormError = `Birth year must be between ${MaxBirthyear - 101} and ${MaxBirthyear - 1}.`;
        }

        FormError = false;
        Busy = true;
        Visible = false;
        SendEvent("Characters/CreateCharacter", {
            Firstname,
            Lastname,
            Birthdate,
            Gender,
            Type: "Normal",
        });
    };

    // Keyboard
    const OnKeyDown = (Event) => {
        if (!Visible) return;
        const Key = Event.key;
        const Typing = Event.target && (Event.target.tagName == "INPUT" || Event.target.tagName == "TEXTAREA");

        if (Stage == "select") {
            if (DeleteConfirm) {
                if (Key == "Enter") ConfirmDelete();
                else if (Key == "Escape" || Key == "Backspace") DeleteConfirm = false;
                return;
            }

            if (Key == "ArrowLeft" || Key == "a" || Key == "A") SetIndex(Index - 1);
            else if (Key == "ArrowRight" || Key == "d" || Key == "D") SetIndex(Index + 1);
            else if (Key == "Enter") Activate();
            else if (Key == "Delete") OpenDelete();
        } else if (Stage == "body") {
            if (Key == "ArrowLeft" || Key == "ArrowRight" || Key == "a" || Key == "A" || Key == "d" || Key == "D") ToggleGender();
            else if (Key == "Enter") ConfirmBody();
            else if (Key == "Escape") BackToSelect();
        } else if (Stage == "info") {
            if (Key == "Enter") { Event.preventDefault(); SubmitInfo(); }
            else if (Key == "Escape") BackToBody();
            else if (!Typing) return;
        }
    };

    // Helpers for positioning things over projected peds.
    const SlotFor = (Entry) => (Entry && Entry.Slot != null ? Slots[Entry.Slot] : null);
    const EntryIndexForSlot = (SlotIdx) => Entries.findIndex(E => E.Slot == SlotIdx);
    const HitboxStyle = (S) => {
        const Height = (S.Bottom - S.Top) * 100;
        return `left: calc(${S.X * 100}vw - ${Height * 0.2}vh); top: ${S.Top * 100}vh; height: ${Height}vh; width: ${Height * 0.4}vh;`;
    };

    $: BeamX = Stage == "select" ? (SlotFor(Current) ? SlotFor(Current).X : null) : (BodySlots[Gender] ? BodySlots[Gender].X : null);
    $: Title = Stage == "select" ? "SELECT CHARACTER" : Stage == "body" ? "BODY SELECTION" : "CHARACTER DETAILS";
</script>

<svelte:window on:keydown={OnKeyDown} />

<AppWrapper AppName="Characters" Focused={Visible}>
    {#if Visible}
        <div class="chars">
            <!-- Teal light beam over the highlighted ped -->
            {#if BeamX != null && Stage != "info"}
                <div class="beam" style="left: {BeamX * 100}vw;"></div>
            {/if}
            <div class="vignette"></div>

            <!-- Header -->
            <div class="header">
                <div class="header-glow"></div>
                <h1>{Title}</h1>
            </div>

            {#if Stage == "select"}
                <!-- Hitboxes and plus icons over the peds -->
                {#each Slots as S, i}
                    {#if S && S.OnScreen}
                        <div
                            class="hitbox"
                            style={HitboxStyle(S)}
                            on:mouseenter={() => SetIndex(EntryIndexForSlot(i))}
                            on:click={() => SetIndex(EntryIndexForSlot(i))}
                            on:dblclick={() => { SetIndex(EntryIndexForSlot(i)); Activate(); }}
                            on:keyup
                        ></div>
                        {#if !Characters[i]}
                            <div class="plus" style="left: {S.X * 100}vw; top: {S.Y * 100}vh;">
                                <i class="fas fa-plus"></i>
                            </div>
                        {/if}
                    {/if}
                {/each}

                <!-- Bottom selector -->
                <div class="selector">
                    <div class="selector-name">
                        {#if Current && Current.Type == "char"}
                            {Current.Char.Name}
                        {:else}
                            NEW CHARACTER
                        {/if}
                    </div>
                    <div class="selector-nav">
                        <div class="nav-arrow" on:click={() => SetIndex(Index - 1)} on:keyup><i class="fas fa-chevron-left"></i></div>
                        <div class="nav-action" on:click={Activate} on:keyup>
                            <span class="kbd kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>
                            <span>{Current && Current.Type == "char" ? "PLAY" : "CREATE"}</span>
                        </div>
                        <div class="nav-arrow" on:click={() => SetIndex(Index + 1)} on:keyup><i class="fas fa-chevron-right"></i></div>
                    </div>
                    {#if Current && Current.Type == "char"}
                        <div class="selector-cid">CID #{Current.Char.Cid}</div>
                    {/if}
                </div>

                {#if DeleteConfirm}
                    <div class="modal-backdrop">
                        <div class="modal">
                            <div class="modal-title">DELETE CHARACTER</div>
                            <div class="modal-body">
                                <p>Are you sure you want to delete <b>{Current.Char.Name}</b> (#{Current.Char.Cid})?</p>
                                <p class="muted">This can <b>NOT</b> be undone.</p>
                                <div class="modal-buttons">
                                    <div class="btn btn-white" on:click={ConfirmDelete} on:keyup>
                                        <span class="kbd kbd-dark kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>
                                        DELETE
                                    </div>
                                    <div class="btn btn-ghost" on:click={() => DeleteConfirm = false} on:keyup>
                                        <span class="kbd kbd-text">ESC</span>
                                        CANCEL
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {/if}
            {/if}

            {#if Stage == "body"}
                {#each BodyTypes as T}
                    {#if BodySlots[T.Gender] && BodySlots[T.Gender].OnScreen}
                        <div
                            class="hitbox"
                            style={HitboxStyle(BodySlots[T.Gender])}
                            on:mouseenter={() => SetGender(T.Gender)}
                            on:click={() => SetGender(T.Gender)}
                            on:dblclick={() => { SetGender(T.Gender); ConfirmBody(); }}
                            on:keyup
                        ></div>
                    {/if}
                {/each}

                <div class="type type-left" class:active={Gender == "Man"}>
                    <div class="type-arrow" on:click={() => SetGender("Man")} on:keyup><i class="fas fa-chevron-left"></i></div>
                    <div class="type-label" on:click={() => Gender == "Man" ? ConfirmBody() : SetGender("Man")} on:keyup>
                        {#if Gender == "Man"}<span class="kbd kbd-dark kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>{/if}
                        <span>TYPE A</span>
                    </div>
                </div>

                <div class="type type-right" class:active={Gender == "Vrouw"}>
                    <div class="type-label" on:click={() => Gender == "Vrouw" ? ConfirmBody() : SetGender("Vrouw")} on:keyup>
                        {#if Gender == "Vrouw"}<span class="kbd kbd-dark kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>{/if}
                        <span>TYPE B</span>
                    </div>
                    <div class="type-arrow" on:click={() => SetGender("Vrouw")} on:keyup><i class="fas fa-chevron-right"></i></div>
                </div>
            {/if}

            {#if Stage == "info"}
                <form class="info" on:submit|preventDefault={SubmitInfo}>
                    <div class="info-title">IDENTITY</div>
                    <div class="info-body">
                        <label>
                            <span>FIRST NAME</span>
                            <input bind:this={FirstnameInput} bind:value={Form.Firstname} maxlength="20" placeholder="John" spellcheck="false" autocomplete="off" />
                        </label>
                        <label>
                            <span>LAST NAME</span>
                            <input bind:value={Form.Lastname} maxlength="20" placeholder="Doe" spellcheck="false" autocomplete="off" />
                        </label>
                        <label>
                            <span>DATE OF BIRTH</span>
                            <input type="date" bind:value={Form.Birthdate} />
                        </label>

                        {#if FormError}
                            <div class="info-error"><i class="fas fa-exclamation-triangle"></i> {FormError}</div>
                        {/if}

                        <div class="info-buttons">
                            <div class="btn btn-white" on:click={SubmitInfo} on:keyup>
                                <span class="kbd kbd-dark kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>
                                CONFIRM
                            </div>
                            <div class="btn btn-ghost" on:click={BackToBody} on:keyup>
                                <span class="kbd kbd-text">ESC</span>
                                BACK
                            </div>
                        </div>
                    </div>
                </form>
            {/if}

            {#if Toast}
                <div class="toast">{Toast}</div>
            {/if}

            <!-- Key hints -->
            <div class="hints">
                {#if Stage != "info"}
                    <div class="hint">
                        <span class="kbd kbd-move"><i class="fas fa-caret-left"></i><i class="fas fa-caret-right"></i></span>
                        MOVE
                    </div>
                    <span class="sep">/</span>
                    <div class="hint">
                        <span class="kbd kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>
                        SELECT
                    </div>
                {:else}
                    <div class="hint">
                        <span class="kbd kbd-enter"><svg viewBox="0 0 24 24"><path d="M19 6v6H7.8l3.6-3.6L10 7l-6 6 6 6 1.4-1.4L7.8 14H21V6z"/></svg></span>
                        CONFIRM
                    </div>
                {/if}
                {#if Stage == "select" && Current && Current.Type == "char"}
                    <span class="sep">/</span>
                    <div class="hint clickable" on:click={OpenDelete} on:keyup>
                        <span class="kbd kbd-text">DEL</span>
                        DELETE
                    </div>
                {/if}
                {#if Stage != "select"}
                    <span class="sep">/</span>
                    <div class="hint clickable" on:click={Stage == "body" ? BackToSelect : BackToBody} on:keyup>
                        <span class="kbd kbd-text">ESC</span>
                        BACK
                    </div>
                {/if}
            </div>
        </div>
    {/if}
</AppWrapper>

<style>
    .chars {
        --teal: #3fd8f2;
        --teal-dim: rgba(63, 216, 242, 0.35);
        --panel: rgba(12, 28, 34, 0.78);
        --panel-border: rgba(255, 255, 255, 0.12);

        position: absolute;
        inset: 0;
        color: white;
        font-family: 'Barlow Condensed', sans-serif;
        font-style: italic;
        font-weight: 700;
        user-select: none;
        overflow: hidden;
    }

    .chars * { box-sizing: border-box; }

    /* Atmosphere */
    .vignette {
        position: absolute;
        inset: 0;
        pointer-events: none;
        background: radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%);
    }

    .beam {
        position: absolute;
        top: 0;
        bottom: 0;
        width: 38vh;
        transform: translateX(-50%);
        pointer-events: none;
        mix-blend-mode: screen;
        background:
            radial-gradient(ellipse 50% 62% at 50% 40%, rgba(63, 216, 242, 0.32), rgba(63, 216, 242, 0) 70%),
            radial-gradient(ellipse 60% 8% at 50% 86%, rgba(63, 216, 242, 0.35), rgba(63, 216, 242, 0) 100%);
        transition: left 0.35s ease;
    }

    /* Header */
    .header {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 9vh;
        display: flex;
        justify-content: center;
        align-items: center;
        pointer-events: none;
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.35) 70%, rgba(0, 0, 0, 0));
    }

    .header-glow {
        position: absolute;
        top: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 50vh;
        height: 7vh;
        background: radial-gradient(ellipse 50% 100% at 50% 0%, rgba(63, 216, 242, 0.55), rgba(63, 216, 242, 0) 100%);
        clip-path: polygon(0 0, 100% 0, 88% 100%, 12% 100%);
    }

    .header-glow::before {
        content: "";
        position: absolute;
        top: 0;
        left: 8%;
        right: 8%;
        height: 0.35vh;
        background: var(--teal);
        box-shadow: 0 0 1.5vh var(--teal);
    }

    .header h1 {
        position: relative;
        margin: 0;
        font-size: 4.4vh;
        font-weight: 800;
        letter-spacing: 0.05vh;
        text-shadow: 0 0.3vh 1vh rgba(0, 0, 0, 0.6);
    }

    /* Key icons */
    .kbd {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 2.2vh;
        height: 2.2vh;
        padding: 0 0.3vh;
        border-radius: 0.35vh;
        background: white;
        color: #10181c;
        font-style: normal;
        font-size: 1.15vh;
        font-weight: 700;
        line-height: 1;
        flex-shrink: 0;
    }

    .kbd svg { width: 1.6vh; height: 1.6vh; fill: currentColor; }
    .kbd-dark { background: #10181c; color: white; }
    .kbd-move { gap: 0.1vh; font-size: 1.4vh; padding: 0 0.35vh; }
    .kbd-text { font-family: Roboto, sans-serif; font-size: 1vh; padding: 0 0.45vh; }

    /* Hitboxes / plus icons */
    .hitbox {
        position: absolute;
        cursor: pointer;
        z-index: 1;
    }

    .plus {
        position: absolute;
        transform: translate(-50%, -50%);
        font-size: 3.4vh;
        color: white;
        pointer-events: none;
        text-shadow: 0 0 1vh rgba(0, 0, 0, 0.6);
        z-index: 2;
    }

    /* Bottom selector */
    .selector {
        position: absolute;
        left: 50%;
        bottom: 0.4vh;
        transform: translateX(-50%);
        width: 50vh;
        z-index: 3;
    }

    .selector-name {
        height: 4.2vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: white;
        color: #0c0f12;
        font-size: 2.3vh;
        font-weight: 800;
        text-transform: uppercase;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        padding: 0 2vh;
    }

    .selector-nav {
        height: 4.4vh;
        display: flex;
        background: var(--panel);
        border: 1px solid var(--panel-border);
        border-top: none;
    }

    .nav-arrow {
        width: 5.2vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.6vh;
        cursor: pointer;
        transition: background 0.15s;
    }

    .nav-arrow:first-child { border-right: 1px solid var(--panel-border); }
    .nav-arrow:last-child { border-left: 1px solid var(--panel-border); }
    .nav-arrow:hover { background: rgba(63, 216, 242, 0.18); }

    .nav-action {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.9vh;
        font-size: 2vh;
        cursor: pointer;
        transition: background 0.15s;
    }

    .nav-action:hover { background: rgba(63, 216, 242, 0.12); }

    .selector-cid {
        position: absolute;
        top: -2.6vh;
        left: 0;
        right: 0;
        text-align: center;
        font-size: 1.6vh;
        color: rgba(255, 255, 255, 0.75);
        text-shadow: 0 0.2vh 0.6vh rgba(0, 0, 0, 0.8);
    }

    /* Body type labels */
    .type {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        display: flex;
        align-items: center;
        gap: 1.6vh;
        z-index: 3;
    }

    .type-left { left: 2vh; }
    .type-right { right: 2vh; }

    .type-arrow {
        font-size: 2.6vh;
        cursor: pointer;
        padding: 1vh 0.5vh;
        text-shadow: 0 0 1vh rgba(0, 0, 0, 0.6);
    }

    .type-label {
        display: flex;
        align-items: center;
        gap: 1vh;
        height: 5.2vh;
        padding: 0 2vh;
        font-size: 2.1vh;
        cursor: pointer;
        text-shadow: 0 0.2vh 0.8vh rgba(0, 0, 0, 0.7);
        transition: background 0.15s, color 0.15s;
    }

    .type.active .type-label {
        min-width: 17vh;
        background: white;
        color: #0c0f12;
        text-shadow: none;
    }

    /* Info form */
    .info {
        position: absolute;
        left: 7vw;
        top: 50%;
        transform: translateY(-50%);
        width: 46vh;
        margin: 0;
        z-index: 3;
    }

    .info-title {
        height: 4.6vh;
        display: flex;
        align-items: center;
        padding: 0 2.2vh;
        background: white;
        color: #0c0f12;
        font-size: 2.4vh;
        font-weight: 800;
    }

    .info-body {
        display: flex;
        flex-direction: column;
        gap: 2.2vh;
        padding: 2.6vh 2.2vh;
        background: var(--panel);
        border: 1px solid var(--panel-border);
        border-top: none;
    }

    .info label {
        display: flex;
        flex-direction: column;
        gap: 0.7vh;
    }

    .info label > span {
        font-size: 1.55vh;
        color: rgba(255, 255, 255, 0.7);
        letter-spacing: 0.05vh;
    }

    .info input {
        height: 4.4vh;
        padding: 0 1.4vh;
        border: none;
        border-bottom: 0.25vh solid rgba(255, 255, 255, 0.25);
        background: rgba(0, 0, 0, 0.35);
        color: white;
        font-family: 'Barlow Condensed', sans-serif;
        font-style: italic;
        font-weight: 600;
        font-size: 2.1vh;
        outline: none;
        color-scheme: dark;
        transition: border-color 0.15s, background 0.15s;
    }

    .info input::placeholder { color: rgba(255, 255, 255, 0.3); }
    .info input:focus { border-bottom-color: var(--teal); background: rgba(63, 216, 242, 0.08); }
    .info input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); opacity: 0.7; cursor: pointer; }

    .info-error {
        font-size: 1.6vh;
        color: #ff6b6b;
        font-weight: 600;
    }

    .info-buttons, .modal-buttons {
        display: flex;
        gap: 1.2vh;
        margin-top: 0.6vh;
    }

    .btn {
        flex: 1;
        height: 4.6vh;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1vh;
        font-size: 2vh;
        cursor: pointer;
        transition: filter 0.15s, background 0.15s;
    }

    .btn-white { background: white; color: #0c0f12; }
    .btn-white:hover { filter: brightness(0.9); }
    .btn-ghost { border: 1px solid var(--panel-border); background: rgba(0, 0, 0, 0.3); }
    .btn-ghost:hover { background: rgba(63, 216, 242, 0.15); }

    /* Delete modal */
    .modal-backdrop {
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.45);
        z-index: 10;
    }

    .modal { width: 52vh; }

    .modal-title {
        height: 4.6vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: white;
        color: #0c0f12;
        font-size: 2.4vh;
        font-weight: 800;
    }

    .modal-body {
        padding: 2.4vh;
        background: var(--panel);
        border: 1px solid var(--panel-border);
        border-top: none;
        text-align: center;
    }

    .modal-body p {
        margin: 0 0 1.2vh 0;
        font-size: 1.9vh;
        font-weight: 600;
    }

    .modal-body .muted { color: rgba(255, 255, 255, 0.6); font-size: 1.6vh; }

    /* Toast */
    .toast {
        position: absolute;
        left: 50%;
        bottom: 13vh;
        transform: translateX(-50%);
        padding: 1vh 2.4vh;
        background: var(--panel);
        border-left: 0.4vh solid #ff6b6b;
        font-size: 1.8vh;
        z-index: 4;
    }

    /* Key hints */
    .hints {
        position: absolute;
        right: 2vh;
        bottom: 1.6vh;
        display: flex;
        align-items: center;
        gap: 1.2vh;
        padding: 0.9vh 1.6vh;
        background: rgba(10, 14, 18, 0.6);
        font-size: 1.55vh;
        z-index: 3;
    }

    .hint {
        display: flex;
        align-items: center;
        gap: 0.7vh;
        white-space: nowrap;
    }

    .hint.clickable { cursor: pointer; }
    .hint.clickable:hover { color: var(--teal); }

    .sep { color: rgba(255, 255, 255, 0.35); font-weight: 600; }
</style>
