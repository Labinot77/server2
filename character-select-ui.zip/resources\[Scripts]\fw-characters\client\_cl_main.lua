FW = exports['fw-core']:GetCoreObject()
LoggedIn = false

local SpawnCam, Peds, InCharacterSelection = false, {}, false
local IsUiReady = false

-- Character creation state
local Stage = "select" -- "select" | "body" | "info"
local HighlightSlot = false
local BodyCam, InfoCam = false, false
local BodyPeds = {}
local SelectedGender = "Man"

-- todo: add logout spots

RegisterNetEvent('FW:Client:OnPlayerLoaded')
AddEventHandler('FW:Client:OnPlayerLoaded', function()
    LoggedIn = true
end)

RegisterNetEvent('FW:Client:OnPlayerUnload')
AddEventHandler('FW:Client:OnPlayerUnload', function()
    LoggedIn = false
end)

RegisterNetEvent("fw-ui:appRestart")
AddEventHandler("fw-ui:appRestart", function(App)
    if not InCharacterSelection then return end
    if App ~= "root" and App ~= "Characters" then return end

    HideSelector()
    Citizen.Wait(50)
    OpenSelector()
end)

RegisterNetEvent("fw-ui:Ready")
AddEventHandler("fw-ui:Ready", function()
    IsUiReady = true
end)

Citizen.CreateThread(function()
	while true do
		if NetworkIsSessionStarted() and IsUiReady then
            Citizen.Wait(750)
            ShutdownLoadingScreenNui(); ShutdownLoadingScreen()
			OpenSelector()
            break
		end
        Citizen.Wait(4)
	end
end)

-- Helpers

local function SetupScenePed(Ped)
    SetEveryoneIgnorePlayer(Ped, true)
    SetEntityInvincible(Ped, true)
    SetBlockingOfNonTemporaryEvents(Ped, true)
    SetPedConfigFlag(Ped, 410, true)
    SetEntityCanBeDamagedByRelationshipGroup(Ped, false, GetHashKey('PLAYER'))
    SetEntityAsMissionEntity(Ped, true, true)
    FreezeEntityPosition(Ped, true)
end

-- Projects a ped to screen space so the UI can place hitboxes / plus icons over it.
local function ProjectPed(Ped)
    if not Ped or not DoesEntityExist(Ped) then return false end

    local Head = GetOffsetFromEntityInWorldCoords(Ped, 0.0, 0.0, 0.85)
    local Chest = GetOffsetFromEntityInWorldCoords(Ped, 0.0, 0.0, 0.4)
    local Feet = GetOffsetFromEntityInWorldCoords(Ped, 0.0, 0.0, -1.0)

    local OnScreen, CX, CY = GetScreenCoordFromWorldCoord(Chest.x, Chest.y, Chest.z)
    local _, _, HY = GetScreenCoordFromWorldCoord(Head.x, Head.y, Head.z)
    local _, _, FY = GetScreenCoordFromWorldCoord(Feet.x, Feet.y, Feet.z)

    return { OnScreen = OnScreen and true or false, X = CX, Y = CY, Top = HY, Bottom = FY }
end

local function SendSlotProjections()
    local Slots = {}
    for i = 1, #Config.PedCoords do
        Slots[i] = ProjectPed(Peds[i]) or { OnScreen = false, X = 0, Y = 0, Top = 0, Bottom = 0 }
    end
    exports['fw-ui']:SendUIMessage('Characters', 'SetSlots', { Slots = Slots })
end

local function SendBodyProjections()
    exports['fw-ui']:SendUIMessage('Characters', 'SetBodySlots', {
        Slots = {
            Man = ProjectPed(BodyPeds.Man),
            Vrouw = ProjectPed(BodyPeds.Vrouw),
        }
    })
end

local function WaitForInterp(Cam, Timeout)
    local Start = GetGameTimer()
    Citizen.Wait(50)
    while IsCamInterpolating(Cam) and GetGameTimer() - Start < (Timeout or 5000) do
        Citizen.Wait(10)
    end
end

local function SetSlotPedsVisible(State)
    for i = 1, #Config.PedCoords do
        if Peds[i] and DoesEntityExist(Peds[i]) then
            SetEntityVisible(Peds[i], State, false)
        end
    end
end

local function DeleteBodyPeds()
    for _, Ped in pairs(BodyPeds) do
        if DoesEntityExist(Ped) then DeletePed(Ped) end
    end
    BodyPeds = {}
end

local function DestroyCreationCams()
    if InfoCam then SetCamActive(InfoCam, false); DestroyCam(InfoCam, false); InfoCam = false end
    if BodyCam then SetCamActive(BodyCam, false); DestroyCam(BodyCam, false); BodyCam = false end
end

local function CreateBodyPeds()
    DeleteBodyPeds()

    local CamPos = Config.BodySelection.CamCoords
    for Gender, Data in pairs(Config.BodySelection.Peds) do
        exports['fw-assets']:RequestModelHash(Data.Model)

        local Ped = CreatePed(0, Data.Model, Data.Coords.x, Data.Coords.y, Data.Coords.z, 0.0, false, false)
        SetEntityHeading(Ped, GetHeadingFromVector_2d(CamPos.x - Data.Coords.x, CamPos.y - Data.Coords.y))
        SetupScenePed(Ped)

        SetPedDefaultComponentVariation(Ped)
        SetPedHeadBlendData(Ped, Data.HeadBlend[1], Data.HeadBlend[2], 0, Data.HeadBlend[1], Data.HeadBlend[2], 0, Data.HeadBlend[3], Data.HeadBlend[3], 0.0, false)
        for ComponentId, Drawable in pairs(Data.Components) do
            SetPedComponentVariation(Ped, ComponentId, Drawable[1], Drawable[2], 0)
        end
        SetPedComponentVariation(Ped, 2, Data.Hair[1], Data.Hair[2], 0)
        ClearAllPedProps(Ped)

        TaskStartScenarioInPlace(Ped, "WORLD_HUMAN_STAND_IMPATIENT_UPRIGHT", 0, false)
        SetModelAsNoLongerNeeded(GetHashKey(Data.Model))

        BodyPeds[Gender] = Ped
    end
end

-- Spotlight on the highlighted ped.
local function StartSpotlightThread()
    Citizen.CreateThread(function()
        local Light = Config.Spotlight
        while InCharacterSelection do
            local Target = false
            if Stage == "select" then
                Target = HighlightSlot and Peds[HighlightSlot]
            else
                Target = BodyPeds[SelectedGender]
            end

            if Target and DoesEntityExist(Target) and IsEntityVisible(Target) then
                local Pos = GetEntityCoords(Target)
                DrawSpotLight(Pos.x, Pos.y, Pos.z + Light.Height, 0.0, 0.0, -1.0, Light.Color[1], Light.Color[2], Light.Color[3], Light.Distance, Light.Brightness, 0.0, Light.Radius, 1.0)
            end

            Citizen.Wait(0)
        end
    end)
end

-- Selector

function OpenSelector()
    if InCharacterSelection then return end

    InCharacterSelection = true
    Stage = "select"
    HighlightSlot = false
    exports['fw-ui']:SetUIFocus(true, true)
    exports['fw-sync']:SetClientSync(false, {Time = 18, Weather = "FOGGY"})

    DoScreenFadeOut(0)
    while not IsScreenFadedOut() do Citizen.Wait(10) end

    SetEntityCoords(PlayerPedId(), Config.HideCoords)
    FreezeEntityPosition(PlayerPedId(), true)
    SetEntityVisible(PlayerPedId(), false)

    SpawnCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", Config.CamCoords.x, Config.CamCoords.y, Config.CamCoords.z, 0.0, 0.0, Config.CamCoords.w, 33.0, false, false)
    SetCamActive(SpawnCam, true)
    RenderScriptCams(true, true, 0, true, false, false)

    StartSpotlightThread()

    Citizen.Wait(1000)
    BuildCharacters()
end

function HideSelector()
    InCharacterSelection = false
    Stage = "select"
    HighlightSlot = false
    exports['fw-ui']:SetUIFocus(false, false)
    exports['fw-ui']:SendUIMessage('Characters', 'SetVisibility', {
        Visible = false
    })

    DoScreenFadeOut(0)

    FreezeEntityPosition(PlayerPedId(), false)
    SetEntityVisible(PlayerPedId(), true)

    DestroyCreationCams()
    SetCamActive(SpawnCam, false)
    DestroyCam(SpawnCam)

    DeleteBodyPeds()
    for i = 1, #Peds, 1 do
        DeletePed(Peds[i])
    end
    Peds = {}
end

function BuildCharacters()
    local Characters = FW.SendCallback("fw-characters:Server:GetCharacters")
    local AllowOverride = FW.SendCallback("fw-characters:Server:AllowOverride")

    -- Coming back from a delete / refresh while in creation: reset to the selection camera.
    if Stage ~= "select" then
        Stage = "select"
        DestroyCreationCams()
        DeleteBodyPeds()
        SetCamActive(SpawnCam, true)
        RenderScriptCams(true, false, 0, true, false, false)
    end

    exports['fw-ui']:SendUIMessage('Characters', 'LoadCharacters', {
        Characters = Characters,
        AllowOverride = AllowOverride,
        SlotCount = #Config.PedCoords,
    })

    for i = 1, #Config.PedCoords, 1 do
        local Model = "mp_m_freemode_01"
        local PedPos = Config.PedCoords[i]

        if Peds[i] then
            DeletePed(Peds[i])
        end

        if Characters[i] and Characters[i].Skin then
            Model = Characters[i].Skin.Model
        end

        -- ig_frans_dobbelen crashes CreatePed native, don't know why. Its the only model that does it...
        if Model == "ig_frans_dobbelen" then
            Model = "a_m_m_golfer_01"
        end

        exports['fw-assets']:RequestModelHash(Model)

        local Ped = CreatePed(0, Model, PedPos.x, PedPos.y, PedPos.z, 0.0, false, false)
        local Heading = GetHeadingFromVector_2d(Config.CamCoords.x - PedPos.x, Config.CamCoords.y - PedPos.y)
        SetEntityHeading(Ped, Heading)
        SetupScenePed(Ped)

        if Characters[i] and Characters[i].Skin then
            TriggerEvent("fw-clothes:Client:LoadSkin", {
                Ped = Ped,
                Clothes = Characters[i].Skin.Clothes
            })
        else
            -- Empty slot: dark, see-through silhouette.
            SetPedDefaultComponentVariation(Ped)
            SetPedHeadBlendData(Ped, 0, 0, 0, 0, 0, 0, 0.0, 0.0, 0.0, false)
            SetPedComponentVariation(Ped, 3, 15, 0, 0)
            SetPedComponentVariation(Ped, 4, 61, 0, 0)
            SetPedComponentVariation(Ped, 6, 34, 0, 0)
            SetPedComponentVariation(Ped, 8, 15, 0, 0)
            SetPedComponentVariation(Ped, 11, 15, 0, 0)
            SetEntityAlpha(Ped, 110, false)
        end

        Peds[i] = Ped
    end

    Citizen.Wait(6000)

    exports['fw-ui']:SendUIMessage('Characters', 'SetVisibility', {
        Visible = true
    })

    if IsScreenFadedOut() then
        DoScreenFadeIn(500)
    end

    Citizen.Wait(100)
    SendSlotProjections()
end

RegisterNetEvent('fw-characters:Client:ShowSelector')
AddEventHandler('fw-characters:Client:ShowSelector', OpenSelector)

RegisterNetEvent("fw-characters:Client:RefreshCharacters")
AddEventHandler("fw-characters:Client:RefreshCharacters", BuildCharacters)

-- NUI: selection

RegisterNUICallback("Characters/SetHighlight", function(Data, Cb)
    HighlightSlot = tonumber(Data.Slot) or false
    Cb("Ok")
end)

-- NUI: creation flow

RegisterNUICallback("Characters/StartCreate", function(Data, Cb)
    if not InCharacterSelection or Stage ~= "select" then return Cb(false) end

    Stage = "body"
    SelectedGender = "Man"
    CreateBodyPeds()

    local Cfg = Config.BodySelection
    if not BodyCam then
        BodyCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", Cfg.CamCoords.x, Cfg.CamCoords.y, Cfg.CamCoords.z, 0.0, 0.0, Cfg.CamCoords.w, Cfg.CamFov, false, false)
    end

    SetCamActiveWithInterp(BodyCam, SpawnCam, Cfg.TransitionTime, 1, 1)
    Citizen.SetTimeout(math.floor(Cfg.TransitionTime * 0.6), function()
        if Stage == "body" then SetSlotPedsVisible(false) end
    end)
    WaitForInterp(BodyCam, Cfg.TransitionTime + 1000)

    SendBodyProjections()
    Cb("Ok")
end)

RegisterNUICallback("Characters/SetBodyHighlight", function(Data, Cb)
    if Data.Gender == "Man" or Data.Gender == "Vrouw" then
        SelectedGender = Data.Gender
    end
    Cb("Ok")
end)

RegisterNUICallback("Characters/CancelCreate", function(Data, Cb)
    if Stage ~= "body" then return Cb("Ok") end

    Stage = "select"
    SetSlotPedsVisible(true)
    SetCamActiveWithInterp(SpawnCam, BodyCam, Config.BodySelection.TransitionTime, 1, 1)
    WaitForInterp(SpawnCam, Config.BodySelection.TransitionTime + 1000)

    DestroyCreationCams()
    DeleteBodyPeds()
    Cb("Ok")
end)

RegisterNUICallback("Characters/SelectBody", function(Data, Cb)
    if Stage ~= "body" then return Cb(false) end
    if Data.Gender == "Man" or Data.Gender == "Vrouw" then
        SelectedGender = Data.Gender
    end

    local Ped = BodyPeds[SelectedGender]
    if not Ped then return Cb(false) end

    Stage = "info"

    -- Hide the other body so only the chosen one is in frame.
    for Gender, Other in pairs(BodyPeds) do
        SetEntityVisible(Other, Gender == SelectedGender, false)
    end

    local Cfg = Config.BodySelection
    local CamPos = GetOffsetFromEntityInWorldCoords(Ped, Cfg.InfoCamOffset.x, Cfg.InfoCamOffset.y, Cfg.InfoCamOffset.z)
    local LookAt = GetOffsetFromEntityInWorldCoords(Ped, Cfg.InfoCamLookOffset.x, Cfg.InfoCamLookOffset.y, Cfg.InfoCamLookOffset.z)

    if InfoCam then DestroyCam(InfoCam, false) end
    InfoCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", CamPos.x, CamPos.y, CamPos.z, 0.0, 0.0, 0.0, Cfg.InfoCamFov, false, false)
    PointCamAtCoord(InfoCam, LookAt.x, LookAt.y, LookAt.z)

    SetCamActiveWithInterp(InfoCam, BodyCam, 1000, 1, 1)
    WaitForInterp(InfoCam, 2000)
    Cb("Ok")
end)

RegisterNUICallback("Characters/BackToBody", function(Data, Cb)
    if Stage ~= "info" then return Cb("Ok") end

    Stage = "body"
    for _, Ped in pairs(BodyPeds) do
        SetEntityVisible(Ped, true, false)
    end

    SetCamActiveWithInterp(BodyCam, InfoCam, 1000, 1, 1)
    WaitForInterp(BodyCam, 2000)

    if InfoCam then DestroyCam(InfoCam, false); InfoCam = false end
    SendBodyProjections()
    Cb("Ok")
end)

RegisterNUICallback("Characters/CreateCharacter", function(Data, Cb)
    if FW.Throttled("create-character", 1000) then
        return Cb(false)
    end

    -- The body chosen on the body selection screen is authoritative.
    Data.Gender = SelectedGender

    HideSelector()
    local Result = FW.SendCallback("fw-character:Server:CreateCharacter", Data)
    Cb(Result)
end)

RegisterNUICallback("Characters/DeleteCharacter", function(Data, Cb)
    DoScreenFadeOut(0)
    FW.TriggerServer("fw-characters:Server:DeleteCharacter", Data)
    Cb("Ok")
end)

RegisterNUICallback("Characters/PlayCharacter", function(Data, Cb)
    HideSelector()
    FW.TriggerServer("fw-characters:Server:PlayCharacter", Data)
    Cb("Ok")
end)

AddEventHandler("onResourceStop", function(Resource)
    if Resource ~= GetCurrentResourceName() then return end

    for i = 1, #Peds, 1 do
        DeletePed(Peds[i])
    end
    DeleteBodyPeds()
end)
